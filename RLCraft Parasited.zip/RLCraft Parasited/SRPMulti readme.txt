planned:
	
	overseers destroy obsidian
	
	potion that disables coth
	potion that turns back assimilated mobs
	
	add points if using lures with COTH
	
	fix preeminent unlock with player phases
	
	fix open to lan freeze
	
	
config
	assim enderdragon can spawn
	preeminents can spawn
	made stage 3+4 beckon+ stage 2-4 dispatcher spawn in phase 8 at low weight
	inf dragons turn to simdrags with coth
	lots of phase spawn changes
	parasitic biome spawns less bad mobs, more hard mobs
	node distance decreased
	end starts at phase 3
	LC starts at phase 8
	can see beckon+dispatcher from far away if stage 3+
	added skyhighPara spawner (ada yelloweye and overseer) in lyca config to disincentivize sky bases
	unlock beckon (3), dispatcher (3,4) and preeminent spawns from phase 6 onwards after you entered LC in phase 8