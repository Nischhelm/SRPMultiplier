planned:
	
	player local phases in ow
	
	fix more phase reset spots
		aivenkrolsummon
		canBiomeStillExist 
	
	overseers destroy obsidian
	
	potion that disables coth
	
	fix open to lan freeze
	
	config: lure values

	
code changes:
	bloodmoon in LC
	phase multiplier
	strange bone stacking
	lures disabled in LC
	mob spawners work
	dimension stat multiplier on parasites (default 1 overworld, 2 nether+end, 4 LC)
	simmermen tp primitives, adapted and pure mobs
	disable LC portal until phase 6
	added nexus specific mob cap
	mostly fixed the weird phase reset on dimension change
	blacklist of nexus mobs that take dmg on rschance=0
	sleeping not giving more penalty with more players (still need to test in multi)
	fix viral limiting on sentient armor ticking up
	end enderman balancing
		simmermen despawn in end
		cap enderman conversion in end to 40. if theres more loaded simmermen, coth killed endermen just die, dont convert
		give end endermen a chance to spawn with rage x in end. if they do, they auto target parasites (default: disabled)
		give end endermen a dmg multiplier on parasites (default: disabled)
		
config
	assim enderdragon can spawn
	preeminents can spawn
	made stage 3+4 beckon+ stage 2-4 dispatcher spawn in phase 8 at low weight
	inf dragons turn to simdrags with coth
	lots of phase spawn changes
	parasitic biome spawns less bad mobs, more hard mobs
	node distance decreased
	end starts at phase 3
	LC starts at phase 8
	can see beckon+dispatcher from far away if stage 3+
	added skyhighPara spawner (ada yelloweye and overseer) in lyca config to disincentivize sky bases
	unlock beckon (3), dispatcher (3,4) and preeminent spawns from phase 6 onwards after you entered LC in phase 8